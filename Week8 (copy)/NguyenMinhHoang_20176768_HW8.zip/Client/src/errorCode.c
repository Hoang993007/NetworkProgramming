#include<stdio.h>

int errorCode() {
return 0;
}
